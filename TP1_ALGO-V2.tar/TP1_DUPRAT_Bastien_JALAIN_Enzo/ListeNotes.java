import java.util.Scanner;

class Element {
    float note;
    Element pred;
    Element succ;

    Element(float note) {
        this.note = note;
        this.pred = null;
        this.succ = null;
    }
}

public class ListeNotes {
    private static int MAX = 100;
    private Element pt_debut;
    private Element pt_fin;
    private int n;

    // Constructeur avec paramètre estTriee
    public ListeNotes(boolean estTriee) {
        this.pt_debut = null;
        this.pt_fin = null;
        this.n = 0;
        Scanner scanner = new Scanner(System.in);
        float note;

        if (estTriee) {
            note = 0; // Initialisation pour entrer dans la boucle
            while (n < MAX && note >= 0) {
                System.out.print("Veuillez rentrer la note " + (n + 1) + ": ");
                note = scanner.nextFloat();
                if (note >= 0) {
                    insertion_triee(note);
                }
            }
            System.out.println("Tableau rempli");
        } else {
            note = 0; // Initialisation pour entrer dans la boucle
            while (n < MAX && note >= 0) {
                System.out.print("Veuillez rentrer la note " + (n + 1) + ": ");
                note = scanner.nextFloat();
                if (note >= 0) {
                    insertion_queue(note);
                }
            }
            System.out.println("Tableau rempli");
        }
    }

    // Méthode pour insérer une note en fin de liste
    public void insertion_queue(float note) {
        if (n < MAX) {
            Element pt_nouveau = new Element(note);
            if (pt_debut == null) {
                pt_debut = pt_nouveau;
                pt_fin = pt_nouveau;
            } else {
                pt_fin.succ = pt_nouveau;
                pt_nouveau.pred = pt_fin;
                pt_fin = pt_nouveau;
            }
            n++;
        } else {
            System.out.println("La liste est pleine.");
        }
    }

    // Méthode pour insérer une note dans une liste déjà triée
    public void insertion_triee(float note) {
        if (n < MAX) {
            Element pt_nouveau = new Element(note);
            if (pt_debut == null || note <= pt_debut.note) {
                pt_nouveau.succ = pt_debut;
                if (pt_debut != null) {
                    pt_debut.pred = pt_nouveau;
                }
                pt_debut = pt_nouveau;
                if (pt_fin == null) {
                    pt_fin = pt_nouveau;
                }
            } else {
                Element pt_courant = pt_debut;
                while (pt_courant.succ != null && note > pt_courant.succ.note) {
                    pt_courant = pt_courant.succ;
                }
                pt_nouveau.succ = pt_courant.succ;
                if (pt_courant.succ != null) {
                    pt_courant.succ.pred = pt_nouveau;
                }
                pt_nouveau.pred = pt_courant;
                pt_courant.succ = pt_nouveau;
                if (pt_nouveau.succ == null) {
                    pt_fin = pt_nouveau;
                }
            }
            n++;
        } else {
            System.out.println("La liste est pleine.");
        }
    }

    // Méthode pour afficher la liste
    public void afficher() {
        if (pt_debut == null) {
            System.out.println("La liste est vide.");
        } else {
            Element pt_courant = pt_debut;
            while (pt_courant != null) {
                System.out.print(pt_courant.note + " ");
                pt_courant = pt_courant.succ;
            }
            System.out.println();
        }
    }
}
