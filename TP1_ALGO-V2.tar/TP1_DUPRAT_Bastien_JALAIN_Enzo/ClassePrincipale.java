import java.util.Scanner;

public class ClassePrincipale {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Souhaitez-vous un Tableau ou une Liste ? (T/L): ");
        String reponse = scanner.next();

        if (reponse.equalsIgnoreCase("T")) {
            System.out.print("Le tableau est-il trié ? (O/N): ");
            String reponseTriee = scanner.next();
            boolean estTriee = reponseTriee.equalsIgnoreCase("O");
            TabNotes notes = new TabNotes(estTriee);
            notes.afficher(); // Affiche le tableau rempli
        } else if (reponse.equalsIgnoreCase("L")) {
            System.out.print("La liste est-elle triée ? (O/N): ");
            String reponseTriee = scanner.next();
            boolean estTriee = reponseTriee.equalsIgnoreCase("O");
            ListeNotes notes = new ListeNotes(estTriee);
            notes.afficher(); // Affiche la liste remplie
        } else {
            System.out.println("Argument invalide : Veuillez rentrer T pour un Tableau ou L pour une Liste");
        }
    }
}