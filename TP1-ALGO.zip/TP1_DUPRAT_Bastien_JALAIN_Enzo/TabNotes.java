import java.util.Scanner;

public class TabNotes {
    private static int MAX = 100;
    private float[] tab;
    private int n;

    // Constructeur avec paramètre estTriee
    public TabNotes(boolean estTriee) {
        this.tab = new float[MAX];
        this.n = 0;
        Scanner scanner = new Scanner(System.in);
        float note;

        if (estTriee) {
            note = 0; // Initialisation pour entrer dans la boucle
            while (n < MAX && note >= 0) {
                System.out.print("Veuillez rentrer la note " + (n + 1) + ": ");
                note = scanner.nextFloat();
                if (note >= 0) {
                    insertion_triee(note);
                }
            }
            System.out.println("Tableau rempli");
        } else {
            note = 0; // Initialisation pour entrer dans la boucle
            while (n < MAX && note >= 0) {
                System.out.print("Veuillez rentrer la note " + (n + 1) + ": ");
                note = scanner.nextFloat();
                if (note >= 0) {
                    insertion_queue(note);
                }
            }
            System.out.println("Tableau rempli");
        }
    }

    // Méthode pour insérer une note en fin de tableau
    public void insertion_queue(float note) {
        if (n < MAX) {
            tab[n] = note;
            n++;
        } else {
            System.out.println("Le tableau est plein.");
        }
    }

    // Méthode pour insérer une note dans un tableau déjà trié
    public void insertion_triee(float note) {
        if (n < MAX) {
            int i = n - 1;
            while (i >= 0 && tab[i] > note) {
                tab[i + 1] = tab[i];
                i--;
            }
            tab[i + 1] = note;
            n++;
        } else {
            System.out.println("Le tableau est plein.");
        }
    }

    // Méthode pour afficher le tableau (utile pour le débogage)
    public void afficher() {
        for (int i = 0; i < n; i++) {
            System.out.print(tab[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Le tableau est-il trié ? (O/N): ");
        String reponse = scanner.next();
        boolean estTriee = reponse.equalsIgnoreCase("O");

        TabNotes notes = new TabNotes(estTriee);
        notes.afficher(); // Affiche le tableau rempli
    }
}
